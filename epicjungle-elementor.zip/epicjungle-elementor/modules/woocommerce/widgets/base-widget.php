<?php
namespace EpicJungleElementor\Modules\Woocommerce\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Base_Widget extends \EpicJungleElementor\Base\Base_Widget {

}